import 'package:flutter_test/flutter_test.dart';
import 'package:vpnsopr/core/vpn_controller.dart';

void main() {
  test('zero byte count is formatted correctly', () {
    expect(formatBytes(0), '۰ بایت');
  });

  test('zero transfer speed is formatted correctly', () {
    expect(formatSpeed(0), '۰ B/s');
  });

  test('one kibibyte is formatted correctly', () {
    expect(formatBytes(1024), '1.00 KB');
  });
}
